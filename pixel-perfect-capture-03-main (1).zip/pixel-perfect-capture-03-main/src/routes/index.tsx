import { createFileRoute } from "@tanstack/react-router";
import {
  Headphones,
  Smartphone,
  Watch,
  Gamepad2,
  Cable,
  BatteryCharging,
  ShieldCheck,
  Tag,
  Truck,
  Phone,
  Mail,
  MapPin,
  MessageCircle,
} from "lucide-react";

import logo from "@/assets/logo22.png.asset.json";
import heroImg from "@/assets/hero-tech.jpg";
import { Aurora } from "@/components/Aurora";
import { useReveal } from "@/hooks/use-reveal";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Shabezza Store — إكسسوارات إلكترونية ومنتجات تقنية في بنغازي" },
      {
        name: "description",
        content:
          "شابيزا ستور في بنغازي، ليبيا: إكسسوارات إلكترونية ومنتجات تقنية بجودة مضمونة وأسعار منافسة مع توصيل لجميع أنحاء ليبيا.",
      },
      { property: "og:title", content: "Shabezza Store — إكسسوارات إلكترونية ومنتجات تقنية" },
      {
        property: "og:description",
        content:
          "جودة مضمونة، أسعار منافسة، وتوصيل لجميع أنحاء ليبيا. تواصل معنا عبر واتساب أو الهاتف.",
      },
    ],
  }),
  component: Index,
});

const WHATSAPP = "https://wa.me/218935141665";

const categories = [
  { icon: Headphones, title: "سماعات", desc: "استمتع بتجربة صوتية أفضل أثناء اللعب والترفيه مع مجموعة من السماعات والإكسسوارات الصوتية" },
  { icon: Smartphone, title: "إكسسوارات الألعاب", desc: "كل ما تحتاجه لتجهيز جلسات اللعب والاستمتاع بتجربة أكثر راحة" },
  { icon: BatteryCharging, title: "شواحن وملحقات", desc: "إكسسوارات عملية للاستخدام اليومي" },
  { icon: Cable, title: "مستلزمات اللعب", desc: "أضف لمسة أفضل إلى إعداداتك مع مجموعة من الإكسسوارات والتجهيزات المخصصة لعشاق الألعاب" },
  { icon: Watch, title: "تبريد أجهزة الألعاب", desc: "قواعد تبريد وملحقات لأجهزة PlayStation" },
  { icon: Gamepad2, title: "يدات تحكم", desc: "تحكم أفضل واستمتع بجلسات اللعب مع يدات تحكم وملحقات لأجهزة الألعاب" },
];

const features = [
  { icon: ShieldCheck, title: "جودة مضمونة", desc: "منتجات مختارة بعناية تضمن لك جودة الاستخدام." },
  { icon: Tag, title: "أسعار منافسة", desc: "أسعار مدروسة تناسب مختلف الاحتياجات." },
  { icon: Truck, title: "توصيل لجميع أنحاء ليبيا", desc: "نوصل طلبك أينما كنت داخل ليبيا." },
];

function Index() {
  useReveal();

  return (
    <div dir="rtl" className="relative min-h-screen overflow-x-hidden">
      <Aurora />

      {/* Header */}
      <header className="sticky top-0 z-50 border-b border-border/60 bg-background/70 backdrop-blur-xl">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
          <a href="#top" className="flex items-center gap-3">
            <img
              src={logo.url}
              alt="شعار Shabezza Store"
              width={44}
              height={44}
              className="h-11 w-11 rounded-full object-cover ring-1 ring-border"
            />
            <span className="text-lg font-bold tracking-tight">Shabezza Store</span>
          </a>
          <nav className="hidden items-center gap-7 text-sm text-muted-foreground md:flex">
            <a href="#categories" className="transition-colors hover:text-foreground">
              المنتجات
            </a>
            <a href="#features" className="transition-colors hover:text-foreground">
              لماذا نحن
            </a>
            <a href="#location" className="transition-colors hover:text-foreground">
              موقعنا
            </a>
            <a href="#contact" className="transition-colors hover:text-foreground">
              تواصل معنا
            </a>
          </nav>
          <a
            href={WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-brand rounded-full px-5 py-2 text-sm font-semibold"
          >
            واتساب
          </a>
        </div>
      </header>

      {/* Hero */}
      <section id="top" className="mx-auto max-w-6xl px-5 pt-14 pb-20 md:pt-24 md:pb-28">
        <div className="grid items-center gap-12 md:grid-cols-2">
          <div className="reveal">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-4 py-1.5 text-xs text-muted-foreground">
              Level up your setup with shabezza
            </span>
            <h1 className="mt-6 text-4xl leading-[1.15] font-extrabold tracking-tight md:text-6xl">
              إكسسوارات إلكترونية
              <br />
              <span className="text-gradient">ومنتجات تقنية</span>
            </h1>
            <p className="mt-5 max-w-md text-base leading-relaxed text-muted-foreground md:text-lg">
              وجهتك الإلكترونية لاكتشاف تشكيلة متنوعة من الإكسسوارات الإلكترونية والمنتجات التقنية، المختارة لتجمع بين العملية، الجودة، والقيمة المناسبة. نوفر لك خيارات تلائم احتياجاتك اليومية وتجربة اللعب، مع خدمة توصيل تغطي جميع أنحاء ليبيا
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <a
                href={WHATSAPP}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-brand rounded-full px-7 py-3 text-sm font-semibold"
              >
                اطلب عبر واتساب
              </a>
              <a href="#categories" className="btn-ghost-brand rounded-full px-7 py-3 text-sm font-semibold">
                تصفّح الأقسام
              </a>
            </div>
          </div>

          <div className="reveal relative">
            <div className="animate-float-soft overflow-hidden rounded-3xl border border-border shadow-[var(--shadow-glow)]">
              <img
                src={heroImg}
                alt="إكسسوارات إلكترونية: سماعات، هاتف، ساعة ذكية ويد تحكم"
                width={1280}
                height={1024}
                className="w-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section id="categories" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
        <div className="reveal max-w-xl">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">إكسسوارات ومنتجات تقنية للألعاب والاستخدام اليومي</h2>
          <p className="mt-3 text-muted-foreground">
            اكتشف تشكيلة مختارة من الإكسسوارات التقنية التي تجمع بين العملية، الراحة، ومتعة الاستخدام لتمنحك تجربة أفضل في كل جلسة
          </p>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {categories.map((c, i) => (
            <article
              key={c.title}
              className="glow-card reveal rounded-2xl p-6"
              style={{ transitionDelay: `${i * 70}ms` }}
            >
              <span className="bg-gradient-brand inline-flex h-11 w-11 items-center justify-center rounded-xl">
                <c.icon className="h-5 w-5 text-primary-foreground" strokeWidth={1.8} />
              </span>
              <h3 className="mt-4 text-lg font-semibold">{c.title}</h3>
              <p className="mt-1.5 text-sm text-muted-foreground">{c.desc}</p>
            </article>
          ))}
        </div>
      </section>

      {/* Features */}
      <section id="features" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
        <div className="grid gap-4 md:grid-cols-3">
          {features.map((f, i) => (
            <article
              key={f.title}
              className="glow-card reveal rounded-2xl p-7 text-center"
              style={{ transitionDelay: `${i * 90}ms` }}
            >
              <span className="mx-auto inline-flex h-14 w-14 items-center justify-center rounded-2xl border border-border bg-muted/40">
                <f.icon className="h-6 w-6 text-accent" strokeWidth={1.7} />
              </span>
              <h3 className="mt-5 text-xl font-bold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{f.desc}</p>
            </article>
          ))}
        </div>
      </section>

      {/* Location */}
      <section id="location" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
        <div className="glow-card reveal flex flex-col items-start gap-6 rounded-3xl p-8 md:flex-row md:items-center md:justify-between md:p-12">
          <div>
            <span className="inline-flex items-center gap-2 text-sm text-accent">
              <MapPin className="h-4 w-4" /> موقعنا
            </span>
            <h2 className="mt-3 text-2xl font-bold md:text-3xl">ليبيا، بنغازي</h2>
            <p className="mt-2 max-w-md text-muted-foreground">
              مقرنا بنغازي، ويمكنك طلب منتجاتك بسهولة لتصلك أينما كنت داخل ليبيا
            </p>
          </div>
          <a
            href={WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            className="btn-brand rounded-full px-7 py-3 text-sm font-semibold"
          >
            تواصل معنا الآن
          </a>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="mx-auto max-w-6xl px-5 py-16 md:py-24">
        <div className="reveal max-w-xl">
          <h2 className="text-3xl font-bold tracking-tight md:text-4xl">تواصل معنا</h2>
          <p className="mt-3 text-muted-foreground">نحن هنا لمساعدتك. اختر الطريقة الأنسب للتواصل معنا، وسنكون سعداء بالرد على استفساراتك وطلباتك</p>
        </div>
        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          <a href="tel:0942927737" className="glow-card reveal rounded-2xl p-6">
            <Phone className="h-5 w-5 text-primary" />
            <h3 className="mt-4 font-semibold">الهاتف</h3>
            <p dir="ltr" className="mt-1 text-sm text-muted-foreground">
              094-2927737
            </p>
          </a>
          <a
            href={WHATSAPP}
            target="_blank"
            rel="noopener noreferrer"
            className="glow-card reveal rounded-2xl p-6"
            style={{ transitionDelay: "80ms" }}
          >
            <MessageCircle className="h-5 w-5 text-accent" />
            <h3 className="mt-4 font-semibold">واتساب</h3>
            <p dir="ltr" className="mt-1 text-sm text-muted-foreground">
              +218 93-5141665
            </p>
          </a>
          <a
            href="mailto:almajdobtaha@gmail.com"
            className="glow-card reveal rounded-2xl p-6"
            style={{ transitionDelay: "160ms" }}
          >
            <Mail className="h-5 w-5 text-secondary" />
            <h3 className="mt-4 font-semibold">البريد الإلكتروني</h3>
            <p dir="ltr" className="mt-1 text-sm break-all text-muted-foreground">
              almajdobtaha@gmail.com
            </p>
          </a>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border/60 py-10">
        <div className="mx-auto flex max-w-6xl flex-col items-center gap-4 px-5 text-center">
          <img
            src={logo.url}
            alt="شعار Shabezza Store"
            width={56}
            height={56}
            loading="lazy"
            className="h-14 w-14 rounded-full object-cover ring-1 ring-border"
          />
          <p className="text-sm text-muted-foreground">
            Shabezza Store — إكسسوارات إلكترونية ومنتجات تقنية، جميع الحقوق محفوظة
          </p>
        </div>
      </footer>
    </div>
  );
}
