const droplets = [
  { left: "4%", delay: "0s", duration: "7s", height: 90, color: "var(--pink)", opacity: 0.55 },
  { left: "11%", delay: "2.8s", duration: "9s", height: 130, color: "var(--blue)", opacity: 0.4 },
  { left: "18%", delay: "5.2s", duration: "6.5s", height: 70, color: "var(--purple)", opacity: 0.5 },
  { left: "25%", delay: "1.1s", duration: "10s", height: 150, color: "var(--blue)", opacity: 0.35 },
  { left: "32%", delay: "4.4s", duration: "8s", height: 100, color: "var(--pink)", opacity: 0.45 },
  { left: "39%", delay: "0.6s", duration: "11s", height: 160, color: "var(--purple)", opacity: 0.3 },
  { left: "46%", delay: "3.5s", duration: "7.5s", height: 85, color: "var(--blue)", opacity: 0.5 },
  { left: "53%", delay: "6.1s", duration: "9.5s", height: 120, color: "var(--pink)", opacity: 0.35 },
  { left: "60%", delay: "1.9s", duration: "6.8s", height: 75, color: "var(--purple)", opacity: 0.55 },
  { left: "67%", delay: "4.8s", duration: "10.5s", height: 140, color: "var(--blue)", opacity: 0.3 },
  { left: "74%", delay: "0.2s", duration: "8.5s", height: 95, color: "var(--pink)", opacity: 0.45 },
  { left: "81%", delay: "3.1s", duration: "7.2s", height: 80, color: "var(--purple)", opacity: 0.5 },
  { left: "88%", delay: "5.7s", duration: "9.8s", height: 125, color: "var(--blue)", opacity: 0.4 },
  { left: "95%", delay: "2.2s", duration: "6.2s", height: 65, color: "var(--pink)", opacity: 0.55 },
  { left: "8%", delay: "6.6s", duration: "12s", height: 170, color: "var(--purple)", opacity: 0.25 },
  { left: "49%", delay: "7.4s", duration: "11.5s", height: 155, color: "var(--pink)", opacity: 0.28 },
];

const blobs = [
  {
    className:
      "animate-blob-a -top-40 right-[-10%] h-[42rem] w-[42rem] bg-secondary",
    morphDelay: "0s",
  },
  {
    className:
      "animate-blob-b top-1/3 left-[-15%] h-[38rem] w-[38rem] bg-accent opacity-35",
    morphDelay: "-6s",
  },
  {
    className:
      "animate-blob-a bottom-[-20%] right-1/4 h-[32rem] w-[32rem] bg-primary opacity-30",
    morphDelay: "-12s",
  },
];

export function Aurora() {
  return (
    <div aria-hidden className="pointer-events-none fixed inset-0 -z-10 overflow-hidden">
      {blobs.map((b, i) => (
        <div
          key={i}
          className={`aurora ${b.className}`}
          style={{ animationDelay: `0s, ${b.morphDelay}` }}
        />
      ))}
      {droplets.map((d, i) => (
        <span
          key={i}
          className="animate-rain-drop absolute rounded-full"
          style={{
            left: d.left,
            top: 0,
            width: 2,
            height: d.height,
            opacity: d.opacity,
            background: `linear-gradient(to bottom, transparent, ${d.color} 55%, ${d.color})`,
            boxShadow: `0 0 12px 2px ${d.color}`,
            animationDelay: d.delay,
            animationDuration: d.duration,
          }}
        />
      ))}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,transparent_45%,var(--navy-deep)_92%)]" />
    </div>
  );
}
